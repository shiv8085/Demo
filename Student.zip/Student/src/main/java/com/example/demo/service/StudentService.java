package com.example.demo.service;

import java.util.Optional;

import com.example.demo.entity.Student;

public interface StudentService {
	
	//add Student 
	public Student addStudent(Student student);
	public Optional<Student> FindStudent(int id);

}
