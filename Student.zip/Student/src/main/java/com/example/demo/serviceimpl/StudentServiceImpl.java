package com.example.demo.serviceimpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.StudentDao;
import com.example.demo.entity.Student;
import com.example.demo.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentDao studentDao;
	
	
	@Override
	public Student addStudent(Student student) {
	
		return studentDao.save(student);
	}


	@Override
	public Optional<Student> FindStudent(int id) {
		return studentDao.findById(id);
		
	}
	

}
